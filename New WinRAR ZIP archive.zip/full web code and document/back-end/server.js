const express = require('express');
const mongoose = require('mongoose');
const fs = require('fs');
const cors = require('cors');
const Contact = require('./models/contact');

const app = express();
app.use(cors());
app.use(express.json());

// ✅ Yehi line yahan honi chahiye
mongoose.connect('mongodb://localhost:27017/contactform', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
})
.then(() => console.log('MongoDB connected'))
.catch(err => console.log(err));



fs.readdirSync('./models').forEach(file => {
    console.log("📁 Found file:", file);
});


// ✅ Route
app.post('/api/contact', async (req, res) => {
    console.log("Received Data:", req.body); // 👈 yeh add karo
    try {
        const contact = new Contact(req.body);
        await contact.save();
        res.status(201).json({ message: 'Message sent successfully!' });
    } catch (err) {
        res.status(500).json({ message: 'Failed to send message', error: err.message });
    }
});


app.listen(3000, () => console.log('Server running on http://localhost:3000'));
